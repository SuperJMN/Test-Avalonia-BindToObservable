using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using DynamicData;
using ReactiveUI;

namespace BindToObservable.ViewModels;

public class MainWindowViewModel : ViewModelBase
{
    private readonly CompositeDisposable disposables = new();

    public MainWindowViewModel()
    {
        var modelList = new[] {1, 2, 3, 4};

        var obs = modelList
            .ToObservable()
            .ToObservableChangeSet(x => x)
            .AsObservableCache()
            .Connect()
            .TransformWithInlineUpdate(i => new MyViewModel(i))
            .Publish();
        
        obs
            .Bind(out var collection)
            .Subscribe()
            .DisposeWith(disposables);

        MyCollection = collection;

        HasSelection = obs
            .AutoRefresh(x => x.IsSelected)
            .ToCollection()
            .Select(x => x.Any(model => model.IsSelected));

        obs.Connect();
    }

    public IObservable<bool> HasSelection { get; }

    public ReadOnlyObservableCollection<MyViewModel> MyCollection { get; }
}

public class MyViewModel : ReactiveObject
{
    private bool isSelected;

    public MyViewModel(int i)
    {
        Number = i;
    }

    public int Number { get; }

    public bool IsSelected
    {
        get => isSelected;
        set => this.RaiseAndSetIfChanged(ref isSelected, value);
    }
}